LOCAL_DATABASE_HOST = '172.16.0.26'
LOCAL_USER = 'cwadmin'
LOCAL_PASSWORD = 'cwadmin'
MASTER_DATABASE = "CI"
DATABASE_PORT = 3306
ORIGIN_NAME = 'origin'
WORKSPACE_ENV_VARIABLE = 'WorkSpace'
# DATABASES = {
# 			 'autobiz': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwacs': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwadvantage': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwarchivedb': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwcampaign': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwes': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwexperience': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwmasterdb': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwnewcar': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'cwq': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'dcrm': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'editcms': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'forums': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'},
# 			 'usedcardb': {'host':'172.16.0.26','user':'ciuser','password':'ci@123'}
# 			}

DATABASES = {
			 'CI': {'host':'172.16.0.26','user':'cwadmin','password':'cwadmin'}
			}
