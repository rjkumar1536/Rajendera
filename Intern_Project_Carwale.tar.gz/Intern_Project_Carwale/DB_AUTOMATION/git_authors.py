
import git
import sys
def main(argv):
	if len(argv) < 1:
		print "Incorrect Command format missing arguments"
		exit(-1)
	REPO_LOCATION =argv[0]
	repo = git.Repo(REPO_LOCATION)
	tree = repo.tree()
	commit_data=[]
	for blob in tree:
	    commit = repo.iter_commits(paths=blob.path, max_count=1).next()
	    commit_data.append(commit)
	    commit_data.append(commit.author)
	    commit_data.append(commit.message)
	    details=str(commit_data).strip('[]')
	    details=details.replace("("," ")
	    details=details.replace("/\n"," ")
	    print "Commit_Details: hii"+details
	    break


if __name__ == '__main__':
	main(sys.argv[1:])
