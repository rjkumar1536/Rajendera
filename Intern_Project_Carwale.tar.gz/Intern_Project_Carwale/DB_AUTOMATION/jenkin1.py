import re 
import pymysql
import logging
import os
import git
import datetime
import logging
import sys
import traceback
import codecs
import string
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from os import getenv
import subprocess
local_database_host = '172.16.0.26'
local_user = 'cwadmin'
local_password = 'cwadmin'
master_database = "CI"
DATABASE_PORT = 3306
ORIGIN_NAME = 'origin'
location="C:/Database_Automation/CIDemoRepository"
conn = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
os.environ["WorkSpace"] = "C:/Database_Automation/CIDemoRepository"
WORKSPACE_ENV_VARIABLE = 'WorkSpace'
FEATURE_CHECKOUT_PATH = os.environ[WORKSPACE_ENV_VARIABLE]
def gitCheckout(commit_hash):
	g = git.Git(FEATURE_CHECKOUT_PATH)
	g.checkout(commit_hash)

def gitDiff(prev_commit_hash,curr_commit_hash,path):
	format = '--name-only'
	fil = []
	g = git.Git(location)
	differ = g.diff('%s..%s' % (prev_commit_hash, curr_commit_hash), format, '--' ,path ).split("\n")
	for line in differ:
		if len(line):
			fil.append(line)
	return fil


def get_Logger(loggerName,fileName):
	logger = logging.getLogger(loggerName)
	logger.setLevel(logging.DEBUG)
	fh = logging.FileHandler(fileName)
	formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
	fh.setFormatter(formatter)
	logger.addHandler(fh)
	return logger

logger = get_Logger("log_file","log_file.log")
def PrintUnexpectedException(logger):
	exc_type ,exc_obj, tb = sys.exc_info()
	f = tb.tb_frame
	lineno = tb.tb_lineno
	filename = f.f_code.co_filename
	logger.error('EXCEPTION IN ({}, LINE {} ): {}'.format(filename, lineno, exc_obj))
def get_revert_num(line):
		flag=0
		if line.lower().find("tables/") >= 0:
			flag=1
		elif line.lower().find("function/") >= 0 :
			flag=2
		elif line.lower().find("views/") >= 0 :
			flag=3
		elif line.lower().find("trigger/") >= 0 :
			flag=4
		elif line.lower().find("stored procedures/") >= 0 :
			flag=5
		return flag
def revert(revert_num,files):
	Update_ScriptChange_db("Revert Started",current_commit_hash,current_branch,"schema_name");
	revert_scripts = get_revert_scripts(revert_num,files)		
	print "________\n revert scripts locations:\n"
	print revert_scripts
	print revert_num
	print "reverting  table scripts "
	if len(revert_scripts) >0 and revert_num>=1:  #REVERTING FOR TABLES
		for path in revert_scripts:
			if path.lower().find("table") >= 0 :
				c = conn.cursor();
				words=path.split("/")
				object_name=words[-1]
				path =location+"/"+path
				path=path.replace("\n"," ")
				x=os.path.isfile(path)
				print"\nReverting file  is",path,"\n"
				if x:
					with open(path, 'r') as f:
						query = " ".join(f.readlines())
						if f :
							print "successful in opening"
						else :
							print "not successfull in opening"
						try:
							logger.debug(query)
							c.execute(query)
						except:
							PrintUnexpectedException(logger)
							print "reverting not successfull"
	#else:
			#print "revert scripts not found...perhaps u forgot to add revert scripts to a particular commit"
	if revert_num > 1: #there is change in sp's n all....so we need to restore the prev version
		print "\nexecuting the previous version stmts.....\n they are :\n" 
		#gitStash()
		gitCheckout(previous_commit_hash)
		#gitFetch(current_branch)
		try:
			if revert_num>=5:#reverting sps
				print "reverting until storedProcedure scripts"
				for path in current_changed_scripts:
					if path.lower().find("stored procedures/") >= 0 :
						path =location+"/"+path
						words=path.split("/")
						proc_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists	
							execute_prev_version(path)
						else:
	 						drop("procedure",proc_name)

	 		if revert_num>=4:
	 			print "reverting until trigger scripts"
	 			for path in current_changed_scripts:
					if path.lower().find("trigger/") >= 0 :
						path =location+"/"+path
						words=path.split("/")
						trigger_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists
							execute_prev_version(path)
						else:
	 						drop("trigger",trigger_name)
	 		if revert_num>=3:
	 			print "reverting until view scripts"
	 			for path in current_changed_scripts:
					if path.lower().find("view/") >= 0 :
						path =location+"/"+path
						words=pathne.split("/")
						view_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists
							execute_prev_version(path)
						else:
	 						drop("view",view_name)
	 		if revert_num>=2:
	 			print "reverting until function scripts"
	 			for path in current_changed_scripts:
					if path.lower().find("function/") >= 0 :
						path =location+"/"+path
						words=path.split("/")
						function_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists
							execute_prev_version(path)
						else:
	 						drop("function",function_name)
	 	except:
	 		gitCheckout(current_commit_hash)
	Update_ScriptChange_db("Revert Completed",current_commit_hash,current_branch,"schema_name");
	gitCheckout(current_commit_hash)

def execute_prev_version(path):
	c = conn.cursor()
	with open(path, 'r') as f:
		if f :
			print "successful in opening",path,"\n"
		else :
			print "not successfull in opening"
		query = " ".join(f.readlines())
		try:
			logger.debug(query)
			c.execute(query)#_____________________
			print "Executed "
		except:
			PrintUnexpectedException(logger)
			print path

def drop(obj,object_name):
	#con = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
	cur=conn.cursor();
	query="drop %s if exists %s;"%(obj,object_name)
	logger.debug(query)
	return cur.execute(query)

def gitMergeBase(branch1,branch2):
	g = git.Git(location)
	commitHash = g.merge_base(branch1,branch2)
	return commitHash

def Update_ScriptChange_db(status,curr_commit_hash,curr_branch,schema_name):
	#con = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
	cur=conn.cursor();
	update_query = "update CIScriptChangeHistory set _status = '%s',updateddate = '%s' where  CommitHash = '%s' and BranchName = '%s' and counter = %s " % (status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],curr_commit_hash,curr_branch,counter)
	x=True
	try:
		logger.debug(update_query)
		x=cur.execute(update_query)
		conn.commit()
	except:
		PrintUnexpectedException(logger)
	return x

def make_Script_Change_Entry(status,curr_commit_hash,curr_branch,schema_name,script_name):
	#script_name.replace("stored procedures","storedProcedure")
	#con = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
	cur=conn.cursor();
	insert_query = "insert into CIScriptChangeHistory  values ('%s','%s','%s','%s','%s','%s','%s') " % (status,curr_commit_hash,curr_branch,schema_name,script_name,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],counter)
	x=True
	try:
		logger.debug(insert_query)
		x=cur.execute(insert_query)
	except:
		PrintUnexpectedException(logger)
	return x

def make_entry_database(branch_name,commit_hash,status,previous_hash): 
	#con = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
	cur=conn.cursor();
	insert_query = "insert into CIDatabaseChangeHistory(BranchName, CommitHash, _status, updateddate,counter,PREV_COMMIT_HASH) values ('%s','%s','%s','%s',%s,'%s') " % (branch_name,commit_hash,status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],counter,previous_hash)
	
	logger.debug(insert_query)
	return cur.execute(insert_query)
def update_database_entry(branch_name,commit_hash,status):
	#con = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
	cur=conn.cursor();
	update_query = "update CIDatabaseChangeHistory set _status = '%s',updateddate = '%s' where  CommitHash = '%s' and BranchName = '%s' and counter = %s " % (status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],commit_hash,branch_name,counter)
	logger.debug(update_query)
	return cur.execute(update_query)
def get_changed_scripts(check,files):
	changed_table_scripts = []
	changed_function_scripts=[]
	changed_view_scripts=[]
	changed_trigger_scripts=[]
	changed_storedProcedures_scripts=[]
	scripts=[]
	for file in files:	
		if file.lower().find("revert_scripts/") == -1:
			if file.lower().find("tables/") >= 0 and check==0:#check is for whether it is deploying curr version or in revert if it is deploying prev version
				changed_table_scripts.append(file.lower())
			elif file.lower().find("functions/") >= 0 :
				changed_function_scripts.append(file.lower())
			elif file.lower().find("views/") >= 0 :
				changed_view_scripts.append(file.lower())
			elif file.lower().find("triggers/") >= 0 :
				changed_trigger_scripts.append(file.lower())
			elif file.lower().find("stored procedures/") >= 0 :
				changed_storedProcedures_scripts.append(file.lower())
	        scripts=changed_table_scripts+changed_function_scripts+changed_view_scripts+changed_trigger_scripts+changed_storedProcedures_scripts
	return scripts

def get_revert_scripts(revert_num,files):
	revert_table_scripts = []
	for file in files:
		if file.lower().find("revert_scripts/") >= 0 :
			if revert_num>=1:
				if file.lower().find("tables/") >= 0:
					revert_table_scripts.append(file.lower())
	return revert_table_scripts


def gitFetch(current_branch):
	g = git.Git(FEATURE_CHECKOUT_PATH)
	g.fetch(ORIGIN_NAME,current_branch)
def get_counter(current_commit_hash,branch_name):
	query = "select counter from CIDatabaseChangeHistory where BranchName = '%s' and CommitHash = '%s' order by counter desc " % (branch_name,current_commit_hash)
	cur=conn.cursor()
	cur.execute(query)
	rows = cur.fetchall()
	if rows == None:
		return 1
	if len(rows) == 0:
		return 1
	else:
		return rows[0][0] + 1
	return 
def get_sha_current(repo):
    sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode('ascii').strip()
    return sha

def is_revert_scripts_available(files):
	changed_scripts=[]
	revert_scripts=[]
	changed_scripts=get_changed_scripts(0,files)
	revert_scripts=get_revert_scripts(5,files)
	for line in changed_scripts:
		words=line.split("/")
		filename=words[-1]
		if line.lower().find("tables/") >= 0:
			revert_file="C:/Database_Automation/CIDemoRepository/Revert_Scripts/Revert_tables/"+"revert_"+filename
			x=os.path.isfile(revert_file)		
			if not x:
				print "\nFile for which revert script unavailable is:",revert_file,"\n"
				return 0
		else:
			revert_file="C:/Database_Automation/CIDemoRepository/Revert_Scripts/"+"revert_"+filename
			x=os.path.isfile(revert_file)	
			if x:
				return 0		
	return 1

def drop_object(path):
	obj=""
	if path.lower().find("stored procedures/") >= 0 :
		obj="procedure"	
	elif path.lower().find("trigger/") >= 0 :
		obj="trigger"
	elif path.lower().find("view/") >= 0 :
		obj="view"
	elif path.lower().find("function/") >= 0 :
		obj="function"
	path =location+"/"+path
	words=path.split("/")
	object_name=words[-1]
	x=os.path.isfile(path)
	drop(obj,object_name)
	return True
def main():
	global counter
	global current_changed_scripts
	repo = git.Repo(location) 
	global current_branch
	global previous_commit_hash
	global current_commit_hash
	current_branch="DB_Auto"
	master_branch="Database_Automation"

	current_commit_hash=get_sha_current(location)
	print "current commit hash",current_commit_hash
	previous_commit_hash= gitMergeBase(current_branch,master_branch)
	print "previous commit hash",previous_commit_hash
	files= gitDiff(current_commit_hash,previous_commit_hash,location)
	with open('C:\Db_auto\output.txt', 'w') as thefile:
		for item in files:
	  		thefile.write("%s\n" % item)
	x= is_revert_scripts_available(files)
	if x:
		print "Yes,Revert Scripts Available\n"
	else:
		print "No,Revert scripts available\n"
	scripts=get_changed_scripts(0,files)
	current_changed_scripts=scripts
	counter = get_counter(current_commit_hash,current_branch)
	done=make_entry_database(current_branch,current_commit_hash,"Started",previous_commit_hash)
	if done:
		print "Database entry successfull"
	else :
		print "Database entry not successfull"
	print scripts
	if len(scripts) == 0:
		logger.info("No database change detected for branch %s and commit %s" % (current_branch,current_commit_hash))
	else:
		logger.info("database files changed in branch %s" %(current_branch))
	flag=0
	for path in scripts:
		c = conn.cursor();
		path =location+"/"+path
		print path
		x=os.path.isfile(path)
		if  not x:
			print "file doesnot exists",path,"\n"
			drop_object(path)
			continue
		path=path.replace("\n"," ")		
		with open(path, 'r') as f:
			if f :
				print "successful in opening"
			else :
				print "not successfull in opening"
			query = " ".join(f.readlines())
			try:
				logger.debug(query)
				make_Script_Change_Entry("Started",current_commit_hash,current_branch,"schema_name",path)
				c.execute(query)#_____________________
				make_Script_Change_Entry("Completed",current_commit_hash,current_branch,"schema_name",path)
				print "Executed "
			except:
				PrintUnexpectedException(logger)
				print path
				flag=get_revert_num(path)
				break
	
	if flag>=1:
		print "\nflag is",flag
		print previous_commit_hash
		revert(flag,files)
	is_execution_successful=update_database_entry(current_branch,current_commit_hash,"COMPLETED")		
	if  is_execution_successful:
		print "Successfully updated in database"
	else:
		print "Unable to make entry in database"
logger.info("\n________________________________________________________________________________\n")
		
			
if __name__ == '__main__':
	main()



