import re 
import pymysql
import logging
import os
import git
import datetime
import logging
import sys
import traceback
import codecs
import string
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from os import getenv
import subprocess
local_database_host = '172.16.0.26'
local_user = 'cwadmin'
local_password = 'cwadmin'
master_database = "CI"
DATABASE_PORT = 3306
ORIGIN_NAME = 'origin'
LOCATION="C:/Database_Automation/CIDemoRepository"
os.environ["WorkSpace"] = "C:/Database_Automation/CIDemoRepository"
WORKSPACE_ENV_VARIABLE = 'WorkSpace'
FEATURE_CHECKOUT_PATH = os.environ[WORKSPACE_ENV_VARIABLE]
databases = {'CI': {'host':'172.16.0.26','user':'cwadmin','password':'cwadmin'},
			'CI': {'host':'172.16.0.26','user':'cwadmin','password':'cwadmin'},
			 
			}
COUNTER=1
PREVIOUS_COMMIT_HASH=""
CURRENT_COMMIT_HASH=""
CURRENT_BRANCH=""
#--------------------------------------logging related functions---------------------------------------#
def get_Logger(loggerName,fileName):
	logger = logging.getLogger(loggerName)
	logger.setLevel(logging.DEBUG)
	fh = logging.FileHandler(fileName)
	formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
	fh.setFormatter(formatter)
	logger.addHandler(fh)
	return logger

def PrintUnexpectedException(logger):
	exc_type ,exc_obj, tb = sys.exc_info()
	f = tb.tb_frame
	lineno = tb.tb_lineno
	filename = f.f_code.co_filename
	logger.error('EXCEPTION IN ({}, LINE {} ): {}'.format(filename, lineno, exc_obj))
logger = get_Logger("log_file","log_file.log")
logger.info("\n_________________\n")

#-------------------------------------database related functions-------------------------------------------#

def make_entry_database(branch_name,commit_hash,status,previous_hash,count=COUNTER): 
	insert_query = "insert into CIDatabaseChangeHistory(BranchName, CommitHash, _status, updateddate,COUNTER,PREV_COMMIT_HASH) values ('%s','%s','%s','%s',%s,'%s') " % (branch_name,commit_hash,status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],count,previous_hash)
	return run_query(insert_query)

def Update_ScriptChange_db(status,curr_commit_hash,curr_branch,schema_name,script_name,count=COUNTER):
	if script_name.lower().find(LOCATION.lower())!=-1:
		script_name=string.replace(script_name,LOCATION+'/',"")
	if script_name.lower().find(LOCATION.lower())!= -1:
		script_name=string.replace(script_name,LOCATION+'/',"")
	update_query = "update CIScriptChangeHistory set _status = '%s',updateddate = '%s' where  CommitHash = '%s' and BranchName = '%s' and COUNTER = %s and ScriptName='%s' " % (status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],curr_commit_hash,curr_branch,count,script_name)
	return run_query(update_query)

def make_Script_Change_Entry(status,curr_commit_hash,curr_branch,schema_name,script_name,count=COUNTER):
	insert_query = "insert into CIScriptChangeHistory  values ('%s','%s','%s','%s','%s','%s','%s') " % (status,curr_commit_hash,curr_branch,schema_name,script_name,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],count)
	return run_query(insert_query)

def update_database_entry(branch_name,commit_hash,status,count=COUNTER):
	update_query = "update CIDatabaseChangeHistory set _status = '%s',updateddate = '%s' where  CommitHash = '%s' and BranchName = '%s' and COUNTER = %s " % (status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],commit_hash,branch_name,count)
	return run_query(update_query)

#---------------------------------------------git related functions---------------------------------------#

def gitCheckout(commit_hash):
 	g = git.Git(FEATURE_CHECKOUT_PATH)
 	g.checkout(commit_hash)

def get_sha_current(repo):
    sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode('ascii').strip()
    return sha
def gitMergeBase(curr_branch,master_branch):
	g = git.Git(LOCATION)
	commitHash = g.merge_base(curr_branch,master_branch)
	return commitHash
	format = '--name-only'
	fil = []
	g = git.Git(LOCATION)
	differ = g.diff('%s..%s' % (prev_commit_hash, curr_commit_hash), format, '--' ,repo_path ).split("\n")
	for line in differ:
		if len(line):
			fil.append(line)
	return fil

def gitMergeBase(branch1,branch2):
	g = git.Git(LOCATION)
	commitHash = g.merge_base(branch1,branch2)
	return commitHash

#------------------------------------------revert related functions------------------------------------------#

def get_revert_num(line):
		flag=0
		if line.lower().find("tables/") >= 0:
			flag=1
		elif line.lower().find("function/") >= 0 :
			flag=2
		elif line.lower().find("views/") >= 0 :
			flag=3
		elif line.lower().find("trigger/") >= 0 :
			flag=4
		elif line.lower().find("stored procedures/") >= 0 :
			flag=5
		return flag
def revert(revert_num,scripts,database,PREV_COMMIT_HASH=PREVIOUS_COMMIT_HASH,CURR_COMMIT_HASH=CURRENT_COMMIT_HASH,CURR_BRANCH=CURRENT_BRANCH,count=COUNTER):
	if revert_num > 1: #there is change in sp's n all....so we need to restore the prev version
		gitCheckout(PREV_COMMIT_HASH)
		try:
			if revert_num>=5:#reverting sps
				for path in scripts:
					if path.lower().find("stored procedures/") >= 0 :
						path =LOCATION+"/"+path
						words=path.split("/")
						proc_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists	
							execute_prev_version(path,database,CURR_COMMIT_HASH,CURR_BRANCH,count)
						else:
	 						drop("procedure",proc_name,database,path,CURR_COMMIT_HASH,CURR_BRANCH,count)

	 		if revert_num>=4:
	 			for path in scripts:
					if path.lower().find("trigger") >= 0 :
						path =LOCATION+"/"+path
						words=path.split("/")
						trigger_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists
							execute_prev_version(path,database,CURR_COMMIT_HASH,CURR_BRANCH,count)
						else:
	 						drop("trigger",trigger_name,database,path,CURR_COMMIT_HASH,CURR_BRANCH,count)
	 		if revert_num>=3:
	 			for path in scripts:
					if path.lower().find("view") >= 0 :
						path =LOCATION+"/"+path
						words=path.split("/")
						view_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists
							execute_prev_version(path,database,CURR_COMMIT_HASH,CURR_BRANCH,count)
						else:
	 						drop("view",view_name,database,path,CURR_COMMIT_HASH,CURR_BRANCH,count)
	 		if revert_num>=2:
	 			for path in scripts:
					if path.lower().find("function/") >= 0 :
						path =LOCATION+"/"+path
						words=path.split("/")
						function_name=words[-1]
						x=os.path.isfile(path)
						if x: #prev version exists
							execute_prev_version(path,database,CURR_COMMIT_HASH,CURR_BRANCH,count)
						else:
	 						drop("function",function_name,database,path,CURR_COMMIT_HASH,CURR_BRANCH,count)
	 	except:
	 		gitCheckout(CURR_COMMIT_HASH)
	 		PrintUnexpectedException(logger)
	gitCheckout(CURR_COMMIT_HASH)

def execute_prev_version(path,database,CURR_COMMIT_HASH=CURRENT_COMMIT_HASH,CURR_BRANCH=CURRENT_BRANCH,count=COUNTER):
	query=get_SQLContent_From_File(path,database,CURR_COMMIT_HASH,CURR_BRANCH,count)
	if run_query(query,host=databases[database]['host'],user=databases[database]['user'],password=databases[database]['password'],database=database):
		if not Update_ScriptChange_db("REVERT COMPLETED",CURR_COMMIT_HASH,CURR_BRANCH,"schema_name",path,count):
			return False
		else:
			print "\n Update successfull for the path",path,"\n"
	else:
		if not Update_ScriptChange_db("REVERT ABORTED",CURR_COMMIT_HASH,CURR_BRANCH,"schema_name",path,count):
			return False
	return True



def drop(obj,object_name,database,path,CURR_COMMIT_HASH=CURRENT_COMMIT_HASH,CURR_BRANCH=CURRENT_BRANCH,count=COUNTER):
	query="drop %s if exists %s;"%(obj,object_name)
	logger.debug(query)
	if run_query(query,host=databases[database]['host'],user=databases[database]['user'],password=databases[database]['password'],database=database):
		if not Update_ScriptChange_db("REVERT COMPLETED",CURR_COMMIT_HASH,CURR_BRANCH,"schema_name",path,count):
		  return False
	else:
		if not Update_ScriptChange_db("REVERT ABORTED",CURR_COMMIT_HASH,CURR_BRANCH,"schema name",path,count):
			return False
	return True

def is_revert_scripts_available(files,database):
	changed_scripts=[]
	revert_scripts=[]
	changed_scripts=get_changed_scripts(0,files,database)
	for line in changed_scripts:
		words=line.split("/")
		filename=words[-1]
		if line.lower().find(database) >= 0:
			if line.lower().find("tables/") >= 0:
				revert_file="C:/Database_Automation/CIDemoRepository/Revert_Scripts/Revert_tables/"+"revert_"+filename
				x=os.path.isfile(revert_file)		
				if not x:
					print "\nFile for which revert script unavailable is:",revert_file,"\n"
					return 0
			else:
				revert_file="C:/Database_Automation/CIDemoRepository/Revert_Scripts/"+"revert_"+filename
				x=os.path.isfile(revert_file)	
				if x:
					return 0		
	return 1

def get_COUNTER(curr_commit_hash,branch_name):
	conn = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
	query = "select COUNTER from CIDatabaseChangeHistory where BranchName = '%s' and CommitHash = '%s' order by COUNTER desc " % (branch_name,curr_commit_hash)
	cur=conn.cursor()
	cur.execute(query)
	rows = cur.fetchall()
	conn.close()
	if rows == None:
		return 1
	if len(rows) == 0:
		return 1
	else:
		return rows[0][0] + 1
	return 

def get_changed_scripts(check,files,database):
	changed_table_scripts = []
	changed_function_scripts=[]
	changed_view_scripts=[]
	changed_trigger_scripts=[]
	changed_storedProcedures_scripts=[]
	scripts=[]
	for file in files:	
		if file.lower().find("revert_scripts/") == -1:
			if file.lower().find(database.lower()) >=0:
				if file.lower().find("tables/") >= 0 and check==0:#check is for whether it is deploying curr version or in revert if it is deploying prev version
					changed_table_scripts.append(file.lower())
				elif file.lower().find("functions/") >= 0 :
					changed_function_scripts.append(file.lower())
				elif file.lower().find("views/") >= 0 :
					changed_view_scripts.append(file.lower())
				elif file.lower().find("triggers/") >= 0 :
					changed_trigger_scripts.append(file.lower())
				elif file.lower().find("stored procedures/") >= 0 :
					changed_storedProcedures_scripts.append(file.lower())
	scripts=changed_table_scripts+changed_function_scripts+changed_view_scripts+changed_trigger_scripts+changed_storedProcedures_scripts
	return scripts

def drop_object(path,database,commit_hash,branch_name,count):
	obj=""
	
	if path.lower().find("stored procedures") >= 0 :
		obj="procedure"	
	elif path.lower().find("trigger") >= 0 :
		obj="trigger"
	elif path.lower().find("view") >= 0 :
		obj="view"
	elif path.lower().find("function") >= 0 :
		obj="function"
	path =LOCATION+"/"+path
	words=path.split("/")
	object_name=words[-1]
	drop(obj,object_name,database,path,commit_hash,branch_name,count)
	return True


#-------------------------------query related functions-----------------------------------------#

def run_query(query,host=local_database_host,user=local_user,password=local_password,database=master_database):
	conn = pymysql.connect(host=host, port=DATABASE_PORT, user=user, passwd=password, db=database,autocommit=False)
	cur = conn.cursor()
	try:    
		logger.debug(query)		
		cur.execute(query)   
		conn.commit()
	except:
		PrintUnexpectedException(logger)
		print "error occured"
		conn.close()
		return False	
	conn.close()
	return True



def get_SQLContent_From_File(filename,database,commit_hash,branch_name,count,directory_path=""):
		length=len(directory_path)
		if length>0:
			path =directory_path+"/"+filename
		else:
			path=filename
		query=""
		x=os.path.isfile(path)
		if  not x and length >0:#in case of execute previous version call length ll be zero
			drop_object(path,database,commit_hash,branch_name,count)
		else:
			if path.find("\n"):
				path=path.replace("\n"," ")		
			with open(path, 'r') as f:
				query = " ".join(f.readlines())
		return query





def run_script(script,commit_hash,branch_name,database,count):
	x=make_Script_Change_Entry("IN PROGRESS",commit_hash,branch_name,"schema_name",script,count)

	script_content = get_SQLContent_From_File(script,database,commit_hash,branch_name,count,FEATURE_CHECKOUT_PATH)

	if len(script_content) >0:
		# script_content = convert_object_script(script_content,script.split("/")[2],database,script.split("/")[-1].split(".")[0])
		if not run_query(script_content,host=databases[database]['host'],user=databases[database]['user'],password=databases[database]['password'],database=database):
			logger.error("there is some error while executing script")
			Update_ScriptChange_db("ABORTED",commit_hash,branch_name,"schema_name",script,count)
		 	return False
		if not Update_ScriptChange_db("COMPLETED",commit_hash,branch_name,"schema_name",script,count):
		  return False
	return True

#--------------------------------main--------------------------------------------#
def main():
	master_branch="Database_Automation"
	CURRENT_BRANCH="Sub_Database_Automation"
	CURRENT_COMMIT_HASH=get_sha_current(LOCATION)
	PREVIOUS_COMMIT_HASH=gitMergeBase(CURRENT_BRANCH,master_branch)
	with open('C:\Db_auto\CIDemoRepository\output.txt', 'r') as f:
		f = f.read().splitlines()
	files = [x for x in f if x and not x.strip().startswith('!')]
	COUNTER = get_COUNTER(CURRENT_COMMIT_HASH,CURRENT_BRANCH)
	done=make_entry_database(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"Started",PREVIOUS_COMMIT_HASH,COUNTER)	
	for database in databases:
		x= is_revert_scripts_available(files,database)
		if x:
			print "Yes,Revert Scripts Available for",database,"\n"
		else:
			print "No,Revert scripts available for ",database,"\n"
			continue;
		flag=0
		current_changed_scripts_db=get_changed_scripts(0,files,database)
		if len(current_changed_scripts_db) == 0:
			logger.info("No database change detected for branch %s and commit %s" % (CURRENT_BRANCH,CURRENT_COMMIT_HASH))
		else:
			logger.info("database files changed in branch %s" %(CURRENT_BRANCH))
		scripts=[]
		for path in current_changed_scripts_db:			
			if run_script(path,CURRENT_COMMIT_HASH,CURRENT_BRANCH,database,COUNTER):
				scripts.insert(0, path)
			else:
				print "Script Execution Unsuccessfull",path,"\n"
				scripts.insert(0, path)
				flag=get_revert_num(path)
				break
		
		try:
			if   flag>0:
				revert(flag,scripts,database,PREVIOUS_COMMIT_HASH,CURRENT_COMMIT_HASH,CURRENT_BRANCH,COUNTER)
				is_execution_successful=update_database_entry(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"REVERTED",COUNTER)
			else :
				is_execution_successful=update_database_entry(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"COMPLETED",COUNTER)

		except:
			is_execution_successful=update_database_entry(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"NOT COMPLETED")		
		if is_execution_successful:
			logger.info("Successfully updated in database")
		else:
			logger.info("Unable to make entry in database")
if __name__ == '__main__':
	main()