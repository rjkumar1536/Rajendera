import requests
import json
import logging
import sys
from requests.auth import HTTPBasicAuth
def get_Logger(loggerName,fileName):
	logger = logging.getLogger(loggerName)
	logger.setLevel(logging.DEBUG)
	fh = logging.FileHandler(fileName)
	formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
	fh.setFormatter(formatter)
	logger.addHandler(fh)
	return logger

def PrintUnexpectedException(logger):
	exc_type ,exc_obj, tb = sys.exc_info()
	f = tb.tb_frame
	lineno = tb.tb_lineno
	filename = f.f_code.co_filename
	logger.error('EXCEPTION IN ({}, LINE {} ): {}'.format(filename, lineno, exc_obj))

logger = get_Logger("log_file","log1_file.log")
logger.info("\n_________________\n")

try:
	head= {'Accept':'application/vnd.github.loki-preview+json','Content-Type':'application/json'}
	url='https://api.github.com/repos/carwale/CIDemoRepository/branches/Sample_DB_Automation/protection'
	# url='https://api.github.com/users/carwale/orgs/'
	res = requests.get(url,headers=head,auth=('Shivanigilla', 'System@789'))
	if(res.ok):
		print "done " 
		print res
	else:
		print "not ok"
		res.raise_for_status()
except:
	res.raise_for_status()
	PrintUnexpectedException(logger)



# import urllib2

# gh_url = 'https://api.github.com/repos/carwale/CIDemoRepository/'
# head= {'Accept':'application/vnd.github.loki-preview+json','Content-Type':'application/json'}
# req = urllib2.Request(gh_url,headers=head)

# password_manager = urllib2.HTTPPasswordMgrWithDefaultRealm()
# password_manager.add_password(None, gh_url, 'Shivanigilla', 'System@789')

# auth_manager = urllib2.HTTPBasicAuthHandler(password_manager)
# opener = urllib2.build_opener(auth_manager)

# urllib2.install_opener(opener)

# handler = urllib2.urlopen(req)

# print handler.getcode()
# print handler.headers.getheader('content-type')



