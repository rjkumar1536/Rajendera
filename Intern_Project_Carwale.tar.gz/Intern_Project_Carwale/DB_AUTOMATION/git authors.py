
import git
import sys
def main(argv):
	if len(argv) < 2:
		print "Incorrect Command format missing arguments"
		exit(-1)
	REPO_LOCATION =argv[0]
	repo = git.Repo(REPO_LOCATION)
	tree = repo.tree()
	commit_data=[]
	for blob in tree:
	    commit = repo.iter_commits(paths=blob.path, max_count=1).next()
	    commit_data.apppend(commit)
	    commit_data.apppend(commit.author)
	    commit_data.apppend(commit.message)
	    print commit_data
	    break


if __name__ == '__main__':
	main(sys.argv[1:])
