import methods
import re 
import pymysql
import logging
import os
import git
import datetime
import logging
import sys
import traceback
import codecs
import string
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from os import getenv
import subprocess
import execute_db_scripts
local_database_host = '172.16.0.26'
local_user = 'cwadmin'
local_password = 'cwadmin'
master_database = "CI"
DATABASE_PORT = 3306
ORIGIN_NAME = 'origin'
LOCATION="C:/Database_Automation/CIDemoRepository"
conn = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)
os.environ["WorkSpace"] = "C:/Database_Automation/CIDemoRepository"
WORKSPACE_ENV_VARIABLE = 'WorkSpace'
FEATURE_CHECKOUT_PATH = os.environ[WORKSPACE_ENV_VARIABLE]
logger = execute_db_scripts.get_Logger("log_file","log_file.log")
CURRENT_COMMIT_HASH=""
CURRENT_BRANCH=""
PREVIOUS_COMMIT_HASH=""

def main():
	master_branch="Database_Automation"
	CURRENT_BRANCH="Sub_Database_Automation"
	CURRENT_COMMIT_HASH=execute_db_scripts.get_sha_current(LOCATION)
	print "CURRENT_COMMIT_HASH",CURRENT_COMMIT_HASH
	PREVIOUS_COMMIT_HASH= execute_db_scripts.gitMergeBase(CURRENT_BRANCH,master_branch)
	print "previous commit hash",PREVIOUS_COMMIT_HASH
	
	counter=execute_db_scripts.get_COUNTER(CURRENT_COMMIT_HASH,CURRENT_BRANCH)
	with open('C:\Db_auto\CIDemoRepository\output.txt', 'r') as f:
		f = f.read().splitlines()
	files = [x for x in f if x and not x.strip().startswith('!')]
	print files
	for item in files:
		item=item.lower()
		execute_db_scripts.make_Script_Change_Entry(" REVERT IN PROGRESS",CURRENT_COMMIT_HASH,CURRENT_BRANCH,"schema_name",item.lower(),counter)
	
	
	try:
		execute_db_scripts.make_entry_database(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"REVERT PART STARTED",PREVIOUS_COMMIT_HASH,counter)
		execute_db_scripts.revert(5,files,"CI",PREVIOUS_COMMIT_HASH,CURRENT_COMMIT_HASH,CURRENT_BRANCH,counter)
		execute_db_scripts.update_database_entry(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"REVERT PART COMPLETED",counter)
	except:
		execute_db_scripts.PrintUnexpectedException(logger)
		execute_db_scripts.update_database_entry(CURRENT_BRANCH,CURRENT_COMMIT_HASH,"REVERT PART ABORTED",counter)
		print "REVERTING UNSUCESSFULL HERE"
	



main()