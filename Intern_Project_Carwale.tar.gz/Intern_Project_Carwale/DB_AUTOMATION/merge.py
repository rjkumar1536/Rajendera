import re 
import pymysql
import logging
import os
import git
import datetime
import logging
import sys
import traceback
import codecs
import string
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from os import getenv
import subprocess
local_database_host = '172.16.0.26'
local_user = 'cwadmin'
local_password = 'cwadmin'
master_database = "CI"
DATABASE_PORT = 3306
location="C:/Db_auto/CIDemoRepository"
conn = pymysql.connect(host=local_database_host, port=DATABASE_PORT, user=local_user, passwd=local_password, db=master_database)

def get_revert_hashes(current_commit_hash,branch_name):
	query = "select prev_commit_hash from CIDatabaseChangeHistory where BranchName = '%s' and CommitHash = '%s' order by counter desc " % (branch_name,previous_commit_hash)
	cur = conn.cursor()
	cur.execute(query)
	rows = cur.fetchall()
	if rows == None:
		return 1
	if len(rows) == 0:
		return 1
	else:
		return rows[0][0]
	return 

def gitDiff(prev_commit_hash,curr_commit_hash,path):
	format = '--name-only'
	fil = []
	g = git.Git(location)
	differ = g.diff('%s..%s' % (prev_commit_hash, curr_commit_hash), format, '--' ,path ).split("\n")
	for line in differ:
		if len(line):
			fil.append(line)
	return fil


def get_Logger(loggerName,fileName):
	logger = logging.getLogger(loggerName)
	logger.setLevel(logging.DEBUG)
	fh = logging.FileHandler(fileName)
	formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
	fh.setFormatter(formatter)
	logger.addHandler(fh)
	return logger

logger = get_Logger("log_file","log_file.log")
def PrintUnexpectedException(logger):
	exc_type ,exc_obj, tb = sys.exc_info()
	f = tb.tb_frame
	lineno = tb.tb_lineno
	filename = f.f_code.co_filename
	logger.error('EXCEPTION IN ({}, LINE {} ): {}'.format(filename, lineno, exc_obj))
def get_revert_num(line):
		flag=0
		if line.lower().find("tables/") >= 0:
			flag=1
		elif line.lower().find("function/") >= 0 :
			flag=2
		elif line.lower().find("views/") >= 0 :
			flag=3
		elif line.lower().find("trigger/") >= 0 :
			flag=4
		elif line.lower().find("stored procedures/") >= 0 :
			flag=5
		return flag
def revert(revert_num,files):
	revert_scripts = get_revert_scripts(revert_num,files)
	if revert_num==1:
		print "reverting  table scripts "
	elif revert_num==2:
		print "reverting until function scripts"
	elif revert_num==3:
		print "reverting until view scripts"
	elif revert_num==4:
		print "reverting until trigger scripts"
	elif revert_num==5:
		print "reverting until storedProcedure scripts"
	print "________\n revert scripts location s:\n"
	print revert_scripts
	print revert_num
	if len(revert_scripts) >0:

		for path in revert_scripts:
			c = conn.cursor();
			path ="C:/Db_auto/CIDemoRepository/"+path
			path=path.replace("\n"," ")
			f = open(path, 'r')
			query = " ".join(f.readlines())
			if f :
				print "successful in opening"
			else :
				print "not successfull in opening"
			try:
				logger.debug(query)
				c.execute(query)
			except:
				PrintUnexpectedException(logger)
				print "reverting not successfull"
	else:
			print "revert scripts not found...perhaps u forgot to add revert scripts to a particular commit"
	if revert_num > 1: #there is change in sp's n all....so we need to restore the prev version
		print "\nexecuting the previous version stmts.....\n they are :\n"

		revert_current_hash=previous_commit_hash
		revert_previous_hash=get_revert_hashes(revert_current_hash,current_branch)
		print "revert_current_hash=",revert_current_hash
		print "revert_previous_hash=",revert_previous_hash
		if revert_previous_hash !=1: #prev version is existing
			texts=[]
			texts=gitDiff(revert_previous_hash,revert_current_hash,location)
			print "\n in revert func __\n",texts
			previous_ver_scripts=get_changed_scripts(1,texts)
			print "\n__________\n "
			print previous_ver_scripts
			for path in previous_ver_scripts:
				c = conn.cursor();
				path ="C:/Db_auto/CIDemoRepository/"+path
				path=path.replace("\n"," ")
				f = open(path, 'r')
				if f :
					print "successful in opening"
				else :
					print "not successfull in opening"
				query = " ".join(f.readlines())
				try:
					logger.debug(query)
					c.execute(query)
					print "Executed"
				except:
					PrintUnexpectedException(logger)
					print path
		else:
		 	print "Sorry...there exists no prev version....Cool..We have already executed the present revert scripts..."
def gitDiff(prev_commit_hash,curr_commit_hash,path):
	format = '--name-only'
	files = []
	g = git.Git(location)
	differ = g.diff('%s..%s' % (prev_commit_hash, curr_commit_hash), format, '--' ,path ).split("\n")
	for line in differ:
		if len(line):
			files.append(line)
	return files
def gitMergeBase(branch1,branch2):
	g = git.Git(location)
	commitHash = g.merge_base(branch1,branch2)
	return commitHash
def make_entry_database(branch_name,commit_hash,status,previous_hash): 
	cur=conn.cursor()
	insert_query = "insert into CIDatabaseChangeHistory(BranchName, CommitHash, _status, updateddate,counter,PREV_COMMIT_HASH) values ('%s','%s','%s','%s',%s,'%s') " % (branch_name,commit_hash,status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],counter,previous_hash)
	logger.debug(insert_query)
	return cur.execute(insert_query)
def update_database_entry(branch_name,commit_hash,status):
	cur=conn.cursor()
	update_query = "update CIDatabaseChangeHistory set _status = '%s',updateddate = '%s' where  CommitHash = '%s' and BranchName = '%s' and counter = %s " % (status,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-7],commit_hash,branch_name,counter)
	logger.debug(update_query)
	return cur.execute(update_query)
def get_changed_scripts(check,files):
	changed_table_scripts = []
	changed_function_scripts=[]
	changed_view_scripts=[]
	changed_trigger_scripts=[]
	changed_storedProcedures_scripts=[]
	scripts=[]
	for file in files:	
		if file.lower().find("revert_scripts/") == -1:
			if file.lower().find("tables/") >= 0 and check==0:
				changed_table_scripts.append(file.lower())
			elif file.lower().find("functions/") >= 0 :
				changed_function_scripts.append(file.lower())
			elif file.lower().find("views/") >= 0 :
				changed_view_scripts.append(file.lower())
			elif file.lower().find("triggers/") >= 0 :
				changed_trigger_scripts.append(file.lower())
			elif file.lower().find("stored procedures/") >= 0 :
				changed_storedProcedures_scripts.append(file.lower())
	        scripts=changed_table_scripts+changed_function_scripts+changed_view_scripts+changed_trigger_scripts+changed_storedProcedures_scripts
	return scripts

def get_revert_scripts(revert_num,files):
	revert_table_scripts = []
	revert_function_scripts=[]
	revert_view_scripts=[]
	revert_trigger_scripts=[]
	revert_storedProcedures_scripts=[]
	revert_scripts = []
	for file in files:
		if file.lower().find("revert_scripts/") >= 0 :
			if revert_num>=1:
				if file.lower().find("tables/") >= 0:
					revert_table_scripts.append(file.lower())
			if revert_num>=2:
				if file.lower().find("functions/") >= 0:
					revert_function_scripts.append(file.lower())
			if revert_num>=3:
				if file.lower().find("views/") >= 0:
					revert_view_scripts.append(file.lower())
			if revert_num>=4:
				if file.lower().find("triggers/") >= 0:
					revert_trigger_scripts.append(file.lower())
			if revert_num>=5:
				if file.lower().find("stored procedures/") >= 0:
					revert_storedProcedures_scripts.append(file.lower())
			revert_scripts=	revert_storedProcedures_scripts+revert_trigger_scripts+revert_view_scripts+revert_function_scripts+revert_table_scripts 
	return revert_scripts



def get_counter(current_commit_hash,branch_name):
	query = "select counter from CIDatabaseChangeHistory where BranchName = '%s' and CommitHash = '%s' order by counter desc " % (branch_name,current_commit_hash)
	cur=conn.cursor()
	cur.execute(query)
	rows = cur.fetchall()
	if rows == None:
		return 1
	if len(rows) == 0:
		return 1
	else:
		return rows[0][0] + 1
	return 
def get_sha_current(repo):
    sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode('ascii').strip()
    return sha
def main():
	global counter
	repo = git.Repo(location) 
	global current_branch
	global previous_commit_hash
	current_branch="gs"
	master_branch="master"
	current_commit_hash=get_sha_current(location)
	print "current commit hash",current_commit_hash
	previous_commit_hash= gitMergeBase(current_branch,master_branch)
	print "previous commit hash",previous_commit_hash
	files= gitDiff(current_commit_hash,previous_commit_hash,location)
	#print files
	scripts=get_changed_scripts(0,files)
	counter = get_counter(current_commit_hash,current_branch)
	done=make_entry_database(current_branch,current_commit_hash,"Started",previous_commit_hash)
	
	if done:
		print "database entry successfull"
	else :
		print "database entry not successfull"
	print scripts
	if len(scripts) == 0:
		logger.info("No database change detected for branch %s and commit %s" % (current_branch,current_commit_hash))
	else:
		logger.info("database files changed in branch %s" %(current_branch))
	flag=0
	#is_execution_successful = update_database_entry(current_branch,current_commit_hash,"COMPLETED")
	for path in scripts:
		c = conn.cursor();
		path ="C:/Db_auto/CIDemoRepository/"+path
		path=path.replace("\n"," ")
		f = open(path, 'r')
		if f :
			print "successful in opening"
		else :
			print "not successfull in opening"
		query = " ".join(f.readlines())
		try:
			logger.debug(query)
			c.execute(query)
			print "Executed "
		except:
			PrintUnexpectedException(logger)
			print path
			flag=get_revert_num(path);
	is_execution_successful=update_database_entry(current_branch,current_commit_hash,"COMPLETED")		
	if flag>=1:
		print "\nflag is",flag
		revert(flag,files)
	if  is_execution_successful:
		#revert_scripts=get_revert_scripts(revert_num)
		print "Successfully updated in database"
	else:
		print "Unable to make entry in database"
logger.info("\n________________________________________________________________________________\n")
		
			
#if __name__ == '__main__':
main()









