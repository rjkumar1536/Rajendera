# import pycurl
# from StringIO import StringIO

# response_buffer = StringIO()
# curl = pycurl.Curl()

# curl.setopt(curl.URL, "https://api.github.com")

# curl.setopt(curl.USERPWD, '%s:%s' % ('Shivanigilla', 'System@789'))


# curl.perform()
# curl.close()

# response_value = response_buffer.getvalue()

from requests.auth import HTTPBasicAuth
requests.get('https://api.github.com/user', auth=HTTPBasicAuth('Shivanigilla', 'System@789'))